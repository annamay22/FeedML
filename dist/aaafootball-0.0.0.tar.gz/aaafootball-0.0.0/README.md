# An AAA weekend project

A sample project for data processing algorithm design course.

Uses the [soccerway][https://www.soccerway.com/] site's data and some personal data hosted on dropbox to create a simple data pipeline with some outputs about a teams history.

[The source for this project is available here][src].


[src]: https://github.com/endremborza/weekndfbl

